extends Node
class_name skill_adjust
#the player's data
var player = null

var stat: CharacterStat = null
var is_attacking: bool = false

@onready var animated_sprite = $"../AnimatedSprite2D"

@onready var knight_skill2_effect = $"../skilleffect/knightskill2effect"
@onready var knight_ultimate_effect = $"../skilleffect/knightultimateeffect"
@onready var princess_basic_attack_effect = $"../skilleffect/basicattackofprincess"
@onready var princess_skill1_effect = $"../skilleffect/skill1effectofprincess"

@onready var knight_skill2_start = $"../skilleffect/knightskill2effect_start"
@onready var knight_ultimate_start = $"../skilleffect/knightultimateeffect_start"
@onready var princess_basic_start = $"../skilleffect/basicattackofprincess_start"
@onready var princess_skill1_start = $"../skilleffect/skill1effectofprincess_start"

@onready var skill_damage_area = $skill_area
@onready var skill_damage_shape = $skill_area/CollisionShape2D

var current_skill_damage: int = 0
var current_skill_name: String = ""
var damaged_enemy_list: Array = []
#set up
func setup(new_player, new_stat: CharacterStat) -> void:
	player = new_player
	stat = new_stat
	hide_all_effects()

	skill_damage_area.monitoring = false
	skill_damage_shape.disabled = true
	
	var signal_callable = Callable(self, "_on_skill_damage_area_body_entered")
	if not skill_damage_area.body_entered.is_connected(signal_callable):
		skill_damage_area.body_entered.connect(signal_callable)
	
# Hide Effects
func hide_all_effects() -> void:
	knight_skill2_effect.visible = false
	knight_ultimate_effect.visible = false
	princess_basic_attack_effect.visible = false
	princess_skill1_effect.visible = false

# play effect at the marker position
func play_effect_at_marker(effect: AnimatedSprite2D, marker: Marker2D, duration: float = 0.5) -> void:
	effect.global_position = marker.global_position
	effect.visible = true
	effect.frame = 0
	effect.play()

	await get_tree().create_timer(duration).timeout

	effect.visible = false

# play effect from marker position and fly forward
func play_flying_effect_from_marker(effect: AnimatedSprite2D, marker: Marker2D, fly_distance: float, duration: float = 0.4) -> void:
	var start_position = marker.global_position
	var direction_sign = 1

	if animated_sprite.flip_h:
		direction_sign = -1

	effect.global_position = start_position
	effect.visible = true
	effect.frame = 0
	effect.flip_h = animated_sprite.flip_h
	effect.play()

	var tween = create_tween()
	tween.tween_property(
		effect,
		"global_position",
		start_position + Vector2(fly_distance * direction_sign, 0),
		duration
	)

	await get_tree().create_timer(duration).timeout

	effect.visible = false
	
# function for the basic attack animation and basic attack attack 
func basic_attack_animation() -> void:
	if stat == null:
		return

	if is_attacking:
		return

	is_attacking = true
	
	print("Basic Attack pressed")
	CombatSystem.basic_attack_1(stat)
	if stat.character_name == "Tea Egg Knight":
		animated_sprite.play("knight basic attack")
		animated_sprite.scale = Vector2(0.35, 0.35)
		
	elif stat.character_name == "Boar Princess":
		animated_sprite.play("princess basic attack")
		play_flying_effect_from_marker(
			princess_basic_attack_effect,
			princess_basic_start,
			300,
			0.3
		)

	await animated_sprite.animation_finished

	is_attacking = false
	
#skill damage area 
func activate_skill_damage_area(marker: Marker2D, damage: int, duration: float, area_scale: Vector2 = Vector2(1, 1), skill_name: String = "") -> void:
	current_skill_damage = damage
	current_skill_name = skill_name
	damaged_enemy_list.clear()

	skill_damage_area.global_position = marker.global_position
	skill_damage_area.scale = area_scale

	skill_damage_shape.disabled = false
	skill_damage_area.monitoring = true

	print("Damage area active:", skill_name, " Damage:", damage)

	await get_tree().create_timer(duration).timeout

	skill_damage_area.monitoring = false
	skill_damage_shape.disabled = true

	current_skill_damage = 0
	current_skill_name = ""
	damaged_enemy_list.clear()

	print("Damage area closed")
#the enemy touch skill and cause damage system 
func _on_skill_damage_area_body_entered(body) -> void:
	if body in damaged_enemy_list:
		return

	damaged_enemy_list.append(body)

	if body.has_method("receive_damage"):
		body.receive_damage(current_skill_damage)
		print("Enemy touched skill area. Damage:", current_skill_damage)

		if current_skill_name == "tea_skill2":
			stat.health += 10
			stat.health = clamp(stat.health, 0, stat.current_max_health)
			print("Tea Egg Knight Skill 2 hit enemy: recovered 10 HP")
			stat.print_stat()
	else:
		print("Enemy touched area but has no receive_damage()")

func use_skill_1_action() -> void:
	if stat == null:
		return

	if is_attacking:
		return

	is_attacking = true

	print("Skill 1 pressed")

	if stat.character_name == "Boar Princess":
		animated_sprite.play("skill 1 of boar princess")
		play_flying_effect_from_marker(
			princess_skill1_effect,
			princess_skill1_start,
			600,
			0.3
			)
		
		activate_skill_damage_area(
		princess_skill1_start,
		stat.current_attack + 10,
		0.4,
		Vector2(2, 1),
		"boar_skill1"
		)
	elif stat.character_name == "Tea Egg Knight":
		animated_sprite.play("skill 1 tea egg knight")
		animated_sprite.scale = Vector2(0.35, 0.35)
	SkillSystem.use_skill_1(stat)
	player.speed = stat.current_movement
	stat.print_stat()

	await animated_sprite.animation_finished

	is_attacking = false


func use_skill_2_action() -> void:
	if stat == null:
		return

	if is_attacking:
		return

	is_attacking = true

	print("Skill 2 pressed")

	if stat.character_name == "Boar Princess":
		animated_sprite.play("princess skill 2")

	elif stat.character_name == "Tea Egg Knight":
		animated_sprite.play("skill 2 tea egg knight")
		animated_sprite.scale = Vector2(0.35, 0.35)
		play_flying_effect_from_marker(
			knight_skill2_effect,
			knight_skill2_start,
			400,
			0.6
		)
		activate_skill_damage_area(
		knight_skill2_start,
		stat.current_attack + 10,
		0.6,
		Vector2(2, 1),
		"tea_skill2"
		)

	SkillSystem.use_skill_2(stat)
	player.speed = stat.current_movement
	stat.print_stat()

	await animated_sprite.animation_finished

	is_attacking = false

# the function for princess when use the ultimate the princess will enhance 6s 
func use_ultimate_action() -> void:
	if stat == null:
		return

	if stat.character_name == "Boar Princess":
		if stat.ultimate_active:
			print("Princess Ultimate is already active")
			return

		print("Ultimate pressed")

		# Start ultimate buff
		SkillSystem.start_princess_ultimate(stat)

		# Make princess bigger
		animated_sprite.scale = Vector2(0.08, 0.08)

		# Update movement speed
		player.speed = stat.current_movement
		print("Princess ultimate speed:", player.speed)

		# Keep standing animation, no ultimate animation

		# Buff lasts 6 seconds
		await get_tree().create_timer(6.0).timeout

		# End ultimate buff
		SkillSystem.end_princess_ultimate(stat)

		# Restore normal size
		animated_sprite.scale = Vector2(0.02, 0.02)

		# Restore movement speed
		player.speed = stat.current_movement
		print("Princess normal speed:", player.speed)
		#the part for the tea egg knight
	elif stat.character_name == "Tea Egg Knight":
		if is_attacking:
			return
			
		is_attacking = true
		print("Ultimate pressed")
		animated_sprite.play("ultimate of tea egg knight")
		animated_sprite.scale = Vector2(0.35, 0.35)
		play_effect_at_marker(
			knight_ultimate_effect,
			knight_ultimate_start,
			0.8
			)
		activate_skill_damage_area(
		knight_ultimate_start,
		stat.current_attack + 30,
		0.8,
		Vector2(2.5, 2),
		"tea_ultimate"
		)

		SkillSystem.use_ultimate(stat)
		player.speed = stat.current_movement
		stat.print_stat()
	
		await animated_sprite.animation_finished
		is_attacking = false

func handle_input() -> void:
	if stat == null:
		return

	if Input.is_action_just_pressed("basic attack"):
		basic_attack_animation()

	if Input.is_action_just_pressed("skill1"):
		if is_attacking:
			return

		if skill_cooldown.can_use_skill(stat, "skill1"):
			skill_cooldown.start_cooldown(stat, "skill1")
			use_skill_1_action()
		else:
			print("Skill 1 cooldown:", ceil(skill_cooldown.get_remaining_time(stat, "skill1")))

	if Input.is_action_just_pressed("skill2"):
		if is_attacking:
			return

		if skill_cooldown.can_use_skill(stat, "skill2"):
			skill_cooldown.start_cooldown(stat, "skill2")
			use_skill_2_action()
		else:
			print("Skill 2 cooldown:", ceil(skill_cooldown.get_remaining_time(stat, "skill2")))

	if Input.is_action_just_pressed("ultimate"):
		# Princess ultimate is buff, do not block basic attack / skill
		if stat.character_name == "Boar Princess":
			if skill_cooldown.can_use_skill(stat, "ultimate"):
				skill_cooldown.start_cooldown(stat, "ultimate")
				use_ultimate_action()
			else:
				print("Ultimate cooldown:", ceil(skill_cooldown.get_remaining_time(stat, "ultimate")))

		# Tea Egg Knight ultimate has animation, so it can be blocked by is_attacking
		elif stat.character_name == "Tea Egg Knight":
			if is_attacking:
				return

			if skill_cooldown.can_use_skill(stat, "ultimate"):
				skill_cooldown.start_cooldown(stat, "ultimate")
				use_ultimate_action()
			else:
				print("Ultimate cooldown:", ceil(skill_cooldown.get_remaining_time(stat, "ultimate")))
